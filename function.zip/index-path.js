'use strict';

exports.handler = async (event) => {
    // Extract request and URI from event
    const request = event.Records[0].cf.request;
    const uri = request.uri;

    // Check if the URI ends with a slash or has no file extension
    if (uri.endsWith('/') || !uri.includes('.')) {
        // Add "index.html" to the URI path
        request.uri = uri.replace(/\/$/, '') + '/index.html';
    }

    // Return the modified request
    return request;
};
